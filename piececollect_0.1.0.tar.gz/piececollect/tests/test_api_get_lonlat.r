dat <- read.csv("./tests/lonlat.csv",stringsAsFactors = FALSE)
